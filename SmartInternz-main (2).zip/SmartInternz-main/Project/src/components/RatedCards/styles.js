import { makeStyles } from "@mui/styles";

export default makeStyles(() => ({

}));
