By building this phenomenal app ,

- I got a decent grip in react.js
- Explored material-ui
- Explored the alan-ai by writing scripts and integrating it with the moviespace app.
